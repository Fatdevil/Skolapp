# Snabbguide – Lärare (SkolApp v0.4.1)
1. Öppna appen, logga in via magic-link.
2. Gå till **Admin** och välj roll **Teacher** (för demo).
3. Gå till **Skapa**: fyll i titel, typ, start/slut → Spara.
4. Se händelsen i **Kalender**. Behöver du ta bort, tryck **Radera** under händelsen.
5. Skicka **testnotis** i Admin, eller skapa en händelse – push går till registrerade enheter.
6. Chatt: skriv meddelanden i **Chatt** (känsliga ord flaggas).
