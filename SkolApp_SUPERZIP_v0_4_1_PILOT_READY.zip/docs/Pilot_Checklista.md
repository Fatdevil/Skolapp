# Pilotchecklista (1 klass)
- [ ] Supabase projekt skapat (EU), URL + service_role/anon keys i backend/.env
- [ ] Schema kört (`database/supabase_schema_v0_4.sql`)
- [ ] SMTP (.env) ifyllt och `/admin/test-email` fungerar
- [ ] CSV med 10–20 adresser för klassen (Admin → förhandsgranska → ladda upp)
- [ ] Mobil(er) registrerade för push (Expo Go startad)
- [ ] Testat att skapa händelser, chatta och att push kommer fram
- [ ] Bestäm **KPI**: adoption (% inloggade), push‑öppningsgrad, “missad info” före/efter
