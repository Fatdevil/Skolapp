# Snabbguide – Förälder (SkolApp v0.4.1)
1. Klicka på inbjudan i e‑posten (magic‑link) och logga in.
2. **Kalender** visar kommande händelser (läxor, idrott, utflykter).
3. **Chatt**: följ informationen från läraren och ställ frågor vid behov.
4. Du får **pushnotiser** när läraren skapar nya händelser eller vid påminnelser.
