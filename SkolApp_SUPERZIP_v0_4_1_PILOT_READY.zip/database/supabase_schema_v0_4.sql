-- SkolApp v0.4.1 – Supabase schema
create table if not exists classes ( id text primary key, name text not null, code text not null );
create table if not exists users ( id text primary key, email text unique, role text not null default 'guardian', loa_level text default 'low', created_at timestamptz default now() );
create table if not exists invitations ( id uuid primary key, email text not null, class_code text not null, token text not null, created_at timestamptz default now() );
create table if not exists devices ( id uuid primary key, class_id text not null, expo_token text unique not null, created_at timestamptz default now() );
create table if not exists events ( id uuid default gen_random_uuid() primary key, class_id text not null, type text not null, title text not null, description text, start timestamptz not null, "end" timestamptz not null, created_at timestamptz default now() );
create table if not exists messages ( id uuid default gen_random_uuid() primary key, class_id text not null, sender_id text, sender_name text not null, text text not null, flagged int default 0, created_at timestamptz default now() );
create table if not exists reminders_sent ( key text primary key, created_at timestamptz default now() );

create index if not exists idx_events_class on events(class_id, start);
create index if not exists idx_messages_class on messages(class_id, created_at desc);

alter table classes enable row level security;
alter table users enable row level security;
alter table events enable row level security;
alter table messages enable row level security;
alter table devices enable row level security;
alter table invitations enable row level security;