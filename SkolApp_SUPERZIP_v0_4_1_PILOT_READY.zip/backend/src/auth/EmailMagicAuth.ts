import { v4 as uuid } from 'uuid';
import type { AuthProvider } from './AuthProvider.js';
export type MagicRecord = { email: string; classCode: string; issuedAt: number };
export const magicTokens = new Map<string, MagicRecord>();
export const EmailMagicAuth: AuthProvider = {
  async initiateLogin({ email, classCode }: { email: string; classCode: string }){
    const token = uuid();
    magicTokens.set(token, { email, classCode, issuedAt: Date.now() });
    const magicLink = `skolapp://login?token=${token}`;
    return { token, magicLink };
  },
  async verifyCallback({ token }: { token: string }){
    const found = magicTokens.get(token);
    if (!found) throw new Error('Invalid token');
    return { sessionToken: token, user: { id: 'user-'+Buffer.from(found.email).toString('hex').slice(0,8), email: found.email, loa: 'low' } };
  },
  async linkBankId(){ return { ok:false }; }
};