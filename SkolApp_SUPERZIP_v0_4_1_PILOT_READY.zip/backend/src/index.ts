import Fastify from 'fastify';
import cors from '@fastify/cors';
import formbody from '@fastify/formbody';
import swagger from '@fastify/swagger';
import swaggerUi from '@fastify/swagger-ui';
import { z } from 'zod';
import dotenv from 'dotenv'; dotenv.config();
import { EmailMagicAuth } from './auth/EmailMagicAuth.js';
import { BankIdAuth } from './auth/BankIdAuth.js';
import { getEmailProvider } from './services/EmailService.js';
import { sendPush } from './services/PushService.js';
import { listEvents, createEvent, deleteEvent } from './repos/eventsRepo.js';
import { listMessages, postMessage } from './repos/messagesRepo.js';
import { registerDevice, getClassTokens } from './repos/devicesRepo.js';
import { createInvitation, getInvitationByToken } from './repos/invitationsRepo.js';
import { upsertUserByEmail } from './repos/usersRepo.js';
import { ensureDefaultClass, getClassByCode } from './repos/classesRepo.js';
import { startReminderWorkerSupabase, getRemindersHealth } from './util/remindersSupabase.js';
import { moderate } from './util/moderation.js';

const app = Fastify({ logger: true });
app.addHook('onRequest', async (req, res) => {
  req.log.info({ id: req.id, path: req.url, method: req.method, role: (req.headers['x-user-role']||'guardian') }, 'incoming');
});

await app.register(cors, { origin: true });
await app.register(formbody);
await app.register(swagger, { openapi:{ info:{ title:'SkolApp API', version:'0.4.1'}, servers:[{url:'http://localhost:'+ (process.env.PORT||3333)}] } });
await app.register(swaggerUi, { routePrefix: '/docs' });

// Capabilities
const bankidEnabled = (process.env.BANKID_ENABLED||'false').toLowerCase()==='true';
app.get('/auth/capabilities', async () => ({ bankid: bankidEnabled, magic: true }));

// Seed default class + start reminders
await ensureDefaultClass();
startReminderWorkerSupabase();

// ---- RBAC helpers ----
type Role = 'guardian' | 'teacher' | 'admin';
function getRoleFromRequest(req: any): Role {
  const h = (req.headers['x-user-role'] || '').toString().toLowerCase();
  if (h === 'teacher' || h === 'admin') return h as Role;
  return 'guardian';
}
function requireRole(req: any, reply: any, allowed: Role[]) {
  const role = getRoleFromRequest(req);
  if (!allowed.includes(role)) {
    reply.code(403).send({ error: 'Forbidden: role '+role+' not allowed' });
    return false;
  }
  return true;
}

// Health
app.get('/health', async () => ({ status: 'ok' }));

// AUTH magic-link
const emailProvider = getEmailProvider();
app.post('/auth/magic/initiate', async (req, reply) => {
  const schema = z.object({ email: z.string().email(), classCode: z.string().min(1) });
  const { email, classCode } = schema.parse(req.body);
  const klass = await getClassByCode(classCode);
  if (!klass) return reply.code(404).send({ error: 'Klasskod hittades inte' });
  const res = await EmailMagicAuth.initiateLogin({ email, classCode });
  req.log.info({ magicLink: res.magicLink, token: res.token, email, classCode }, 'MVP magic link');
  return { ok: true, token: res.token };
});

app.post('/auth/magic/verify', async (req, reply) => {
  const schema = z.object({ token: z.string().min(10) });
  const { token } = schema.parse(req.body);
  const inv = await getInvitationByToken(token);
  if (!inv) return reply.code(400).send({ error: 'Ogiltig token' });
  const user = await upsertUserByEmail(inv.email, 'guardian');
  return { sessionToken: 'dev-session', user: { id: user.id, email: user.email, role: user.role } };
});

// Admin: invites (admin only)
app.post('/admin/invitations', async (req, reply) => {
  if(!requireRole(req, reply, ['admin'])) return;
  const schema = z.object({ csvText: z.string().min(1) });
  const { csvText } = schema.parse(req.body);
  const lines = csvText.trim().split(/\r?\n/);
  const header = lines.shift() || '';
  const cols = header.split(',').map(s => s.trim().toLowerCase());
  const emailIdx = cols.indexOf('email'); const classIdx = cols.indexOf('classcode');
  if (emailIdx < 0 || classIdx < 0) return reply.code(400).send({ error: 'CSV måste ha kolumner: email,classCode' });
  let count = 0;
  for (const line of lines) {
    const parts = line.split(',').map(s => s.trim());
    if (parts.length < 2) continue;
    const email = parts[emailIdx]; const classCode = parts[classIdx];
    const res = await EmailMagicAuth.initiateLogin({ email, classCode });
    const appLink = `skolapp://login?token=${res.token}`;
    const webLink = `https://app.skolapp.dev/login?token=${res.token}`;
    await createInvitation(email, classCode, res.token);
    await emailProvider.sendInvite(email, 'Din inbjudan till SkolApp', `Hej!\n\nKlicka för att logga in: ${webLink}\n(Om du har appen installerad kan denna länk öppna appen direkt: ${appLink})\n\nHälsningar, SkolApp`, `<p>Hej!</p><p>Klicka för att logga in: <a href="${webLink}">${webLink}</a></p><p>App-länk: <a href="${appLink}">${appLink}</a></p><p>/SkolApp</p>`);
    count++;
  }
  return { ok: true, count };
});

// Admin: test push/email (admin only)
app.post('/admin/test-push', async (req, reply) => {
  if(!requireRole(req, reply, ['admin'])) return;
  const schema = z.object({ classId: z.string(), title: z.string(), body: z.string() });
  const { classId, title, body } = schema.parse(req.body);
  const tokens = await getClassTokens(classId);
  return await sendPush(tokens, title, body);
});

app.post('/admin/test-email', async (req, reply) => {
  if(!requireRole(req, reply, ['admin'])) return;
  try {
    await emailProvider.sendInvite('you@example.com','Test från SkolApp','Hej från SkolApp – SMTP funkar!');
    return { ok:true };
  } catch (e:any) {
    req.log.error(e);
    return reply.code(500).send({ ok:false, error:e.message });
  }
});

// Devices & Push
app.post('/devices/register', async (req) => {
  const schema = z.object({ expoPushToken: z.string().min(10), classId: z.string() });
  const { expoPushToken, classId } = schema.parse(req.body);
  await registerDevice(classId, expoPushToken);
  return { ok: true };
});

// Events (teacher/admin create/delete)
app.get('/classes/:id/events', async (req) => {
  const { id } = (req.params as any);
  return await listEvents(id);
});
app.post('/events', async (req, reply) => {
  if(!requireRole(req, reply, ['teacher','admin'])) return;
  const schema = z.object({ classId: z.string(), type: z.string(), title: z.string(), description: z.string().optional(), start: z.string(), end: z.string() });
  const body = schema.parse(req.body);
  const evt = await createEvent(body);
  const tokens = await getClassTokens(body.classId);
  await sendPush(tokens, `Ny ${body.type.toLowerCase()} i klassen`, `${body.title} – ${new Date(body.start).toLocaleString()}`);
  return evt;
});
app.delete('/events/:id', async (req, reply) => {
  if(!requireRole(req, reply, ['teacher','admin'])) return;
  const { id } = (req.params as any);
  return await deleteEvent(id);
});

// Messages
app.get('/classes/:id/messages', async (req) => {
  const { id } = (req.params as any);
  return await listMessages(id);
});
app.post('/messages', async (req) => {
  const schema = z.object({ classId: z.string(), text: z.string().min(1) });
  const body = schema.parse(req.body);
  const mod = moderate(body.text);
  const msg = await postMessage({ classId: body.classId, senderId:'g1', senderName:'Anna Andersson', text: body.text, flagged: !!mod.flagged });
  return msg;
});

// BankID (stub)
app.post('/auth/bankid/initiate', async (req, reply) => {
  if (!bankidEnabled) return reply.code(501).send({ error: 'BankID inte aktiverat (BANKID_ENABLED=false)' });
  const schema = z.object({ personalNumber: z.string().optional(), device: z.enum(['mobile','desktop']).default('mobile') });
  const body = schema.parse(req.body || {});
  return await BankIdAuth.initiateLogin({ personalNumber: body.personalNumber, device: body.device });
});
app.post('/auth/bankid/collect', async (req, reply) => {
  if (!bankidEnabled) return reply.code(501).send({ error: 'BankID inte aktiverat (BANKID_ENABLED=false)' });
  const schema = z.object({ orderRef: z.string().min(3) }); const { orderRef } = schema.parse(req.body || {});
  return await BankIdAuth.verifyCallback({ orderRef });
});

// Reminders health
app.get('/reminders/health', async () => getRemindersHealth());

const port = Number(process.env.PORT || 3333);
app.listen({ port, host: '0.0.0.0' }).then(()=>console.log(`API http://localhost:${port} (docs /docs)`));