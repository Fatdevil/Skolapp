import { getSupabase } from '../db/supabase.js';
export async function createInvitation(email:string,classCode:string,token:string){
  const sb=getSupabase(); const row={id:crypto.randomUUID(),email,class_code:classCode,token,created_at:new Date().toISOString()};
  const {data,error}=await sb.from('invitations').insert(row).select('*').single(); if(error) throw error; return data;
}
export async function getInvitationByToken(token:string){
  const sb=getSupabase(); const {data,error}=await sb.from('invitations').select('*').eq('token',token).single();
  if(error) throw error; return data;
}