import { getSupabase } from '../db/supabase.js';
export async function upsertUserByEmail(email:string,role:'guardian'|'teacher'|'admin'='guardian'){
  const sb=getSupabase(); const id='user-'+Buffer.from(email).toString('hex').slice(0,8);
  const row={id,email,role,loa_level:'low',created_at:new Date().toISOString()};
  const {data,error}=await sb.from('users').upsert(row,{onConflict:'id'}).select('*').single(); if(error) throw error; return data;
}